package jediGalaxy;

public class Galaxy {
    private Field field;
    private Jedi jedi;
    private EvilPower evilPower;

    public Galaxy(Field field) {
        this.field = field;
        jedi = new Jedi();
        evilPower = new EvilPower();
    }

    public int moveJedi(int jediRow, int jediCol) {
        return jedi.move(jediRow, jediCol, field);
    }

    public void moveEvil(int evilRow, int evilCol) {
        evilPower.move(evilRow, evilCol, field);
    }
}
